const Suppliers = Object.freeze({
    TBO : "TBO",
    TRIPJACK : "TRIPJACK",
    RIYA : "RIYA"
});